from setuptools import setup, find_packages

# run as python setup.py sdist

VERSION = "0.1"
setup(
    name="KiinClient",  # How you named your package folder (MyLib)
    version=VERSION,  # Start with a small number and increase it with every change you make
    packages=find_packages(),
    package_data={"": ["*.dll", "*.py"]},
    license="MIT",  # Chose a license from here: https://help.github.com/articles/licensing-a-repository
    description="Client library for interacting with the guest server ",  # Give a short description about your library
    author="roger",  # Type in your name
    author_email="pypi@kiin.tech",  # Type in your E-Mail
    url="https://github.com/user/reponame",  # Provide either the link to your github or to your website
    download_url="https://github.com/user/reponame/archive/v_01.tar.gz",  # I explain this later on
    keywords=[
        "guest",
        "server",
        "KEYWORDS",
    ],  # Keywords that define your package best
    install_requires=[  # I get to this in a second
        "pythonnet",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",  # Chose either "3 - Alpha", "4 - Beta" or "5 - Production/Stable" as the current state of your package
        "Intended Audience :: Developers",  # Define that your audience are developers
        "Topic :: Software Development :: Build Tools",
        "License :: OSI Approved :: MIT License",  # Again, pick a license
        "Programming Language :: Python :: 3",  # Specify which pyhton versions that you want to support
        "Programming Language :: Python :: 3.11",
    ],
)
