import sys
import clr
import pathlib

import System

currentPath = pathlib.Path(__file__).parent.resolve()

dllname = "guestxr_client"
voicedllname = "guestxr_voice_client"

sys.path.append(str(currentPath))
clr.AddReference(dllname)
clr.AddReference(voicedllname)

from Vbw.GuestXr.Library import GuestXrHeadless as Guest
from Vbw.GuestXr.Library import AnimationMode
from Vbw.GuestXrVoice.Library import VBWVoiceClient as VoiceGuest


def get_dll_version(dll_path):
    assembly = System.Reflection.Assembly.LoadFrom(dll_path)
    return assembly.GetName().Version


def printVersion(dllname):
    dll_path = str(currentPath / f"{dllname}.dll")
    version = get_dll_version(dll_path)
    print(f"Version of {dllname}.dll: {version}")


printVersion(dllname)
printVersion(voicedllname)
